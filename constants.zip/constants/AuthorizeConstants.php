<?php
class AuthorizeConstants
{
	//merchant credentials
	const MERCHANT_LOGIN_ID = "2Q6t4sMM";
	const MERCHANT_TRANSACTION_KEY = "73K2WW23nqNTd7cv";
}
