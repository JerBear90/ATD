<?php
class AuthorizeConstants
{
  //merchant credentials
  const MERCHANT_LOGIN_ID = "585B3eS2sWgx";
  const MERCHANT_TRANSACTION_KEY = "93k57E53KWuh8z6R";
}
